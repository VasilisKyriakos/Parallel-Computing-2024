
AVAILABLE:

multistart_mds_seq: sequential implementation of the hybrid multistart+mds method

TODO: 

multistart_mds_omp: parallel implementation with OpenMP
multistart_mds_omp_tasks: (nested) parallel implementation with OpenMP tasks
multistart_mds_mpi: parallel implementation with MPI
